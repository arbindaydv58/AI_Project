"""Telegram bot channel."""

from __future__ import annotations

import base64
import os
import threading
import time
from typing import TYPE_CHECKING

from .agent import Agent
from .common import dim, red, yellow
from .errors import EngineError
from .http_utils import http_json, http_open

if TYPE_CHECKING:
    from .app import App


class TelegramBot:
    def __init__(self, app: "App"):
        self.app = app
        c = app.cfg
        self.token = os.environ.get(c.get("telegram.token_env") or "", "") or c.get("telegram.token", "")
        self.allowed = {int(x) for x in c.get("telegram.allowed_chat_ids") or []}
        self.sessions: dict[int, str] = {}

    @staticmethod
    def push(app: "App", text: str):
        c = app.cfg
        token = os.environ.get(c.get("telegram.token_env") or "", "") or c.get("telegram.token", "")
        ids = c.get("telegram.notify_chat_ids") or []
        if not token or not ids:
            return
        bot = TelegramBot(app)
        for cid in ids:
            try:
                bot.send(int(cid), text)
            except Exception:
                pass

    def api(self, method: str, timeout: float = 40, **params):
        d = http_json(f"https://api.telegram.org/bot{self.token}/{method}", params, timeout=timeout)
        if not d or not d.get("ok"):
            raise EngineError(f"Telegram {method} failed: {d}")
        return d["result"]

    def send(self, chat_id: int, text: str):
        text = text or "(empty)"
        for i in range(0, len(text), 4000):
            self.api("sendMessage", chat_id=chat_id, text=text[i:i + 4000])

    def _photo_b64(self, msg) -> list[str]:
        photos = msg.get("photo") or []
        if not photos:
            return []
        f = self.api("getFile", file_id=photos[-1]["file_id"])
        with http_open(f"https://api.telegram.org/file/bot{self.token}/{f['file_path']}", timeout=30) as r:
            return [base64.b64encode(r.read()).decode()]

    def run(self, stop: threading.Event, log=print):
        if not self.token:
            log(yellow("[telegram] no bot token (set TELEGRAM_BOT_TOKEN) - skipping"))
            return
        me = self.api("getMe")
        log(dim(f"[telegram] connected as @{me.get('username')}"))
        offset = 0
        allow_risky = bool(self.app.cfg.get("telegram.allow_risky_tools", False))
        while not stop.is_set():
            try:
                updates = (http_json(f"https://api.telegram.org/bot{self.token}/getUpdates",
                                     {"offset": offset, "timeout": 25}, timeout=40) or {}).get("result", [])
            except Exception as e:
                log(red(f"[telegram] {e}"))
                stop.wait(5)
                continue
            for u in updates:
                offset = u["update_id"] + 1
                msg = u.get("message") or {}
                chat = (msg.get("chat") or {}).get("id")
                text = msg.get("text") or msg.get("caption") or ""
                if not chat:
                    continue
                if chat not in self.allowed:
                    self.send(chat, f"Not authorised. Your chat id is {chat}. Add it with:\n"
                                    f"jarvis config set telegram.allowed_chat_ids '[{chat}]'")
                    continue
                if text.strip() in ("/start", "/help"):
                    self.send(chat, "Hi, I'm Jarvis. Send me a message or photo. /new starts a fresh conversation.")
                    continue
                if text.strip() == "/new":
                    self.sessions[chat] = f"tg-{chat}-{int(time.time())}"
                    self.send(chat, "Started a new conversation.")
                    continue
                try:
                    self.api("sendChatAction", chat_id=chat, action="typing")
                    imgs = self._photo_b64(msg)
                    ag = Agent(self.app, session_id=self.sessions.get(chat, f"tg-{chat}"),
                               approver=lambda n, a: allow_risky)
                    reply = ag.run(text or "Describe this image.", images=imgs or None)
                except Exception as e:
                    reply = f"Error: {e}"
                self.send(chat, reply)
