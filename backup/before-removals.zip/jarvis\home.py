"""Home Assistant REST helpers and device lookup."""

from __future__ import annotations

import os
import re
import time
from typing import TYPE_CHECKING

from .errors import EngineError
from .http_utils import http_json

if TYPE_CHECKING:
    from .app import App


DOMAIN_WORDS = {"light": "light", "lights": "light", "lamp": "light", "lamps": "light", "bulb": "light",
                "fan": "fan", "fans": "fan", "tv": "media_player", "television": "media_player",
                "speaker": "media_player", "music": "media_player", "thermostat": "climate", "heating": "climate",
                "heater": "climate", "ac": "climate", "aircon": "climate", "plug": "switch", "socket": "switch",
                "switch": "switch", "lock": "lock", "door": "lock", "blinds": "cover", "curtains": "cover",
                "shades": "cover", "garage": "cover", "scene": "scene", "vacuum": "vacuum", "camera": "camera",
                "sensor": "sensor", "temperature": "sensor"}
_HA_CACHE: dict = {"t": 0.0, "states": []}


def ha_conf(app: "App") -> tuple[str, str]:
    url = (app.cfg.get("home_assistant.url") or "").rstrip("/")
    token = os.environ.get(app.cfg.get("home_assistant.token_env") or "HA_TOKEN", "") or app.cfg.get("home_assistant.token", "")
    return url, token


def ha_request(app: "App", method: str, path: str, data=None):
    url, token = ha_conf(app)
    if not url or not token:
        raise EngineError("Home Assistant is not set up. Run: jarvis config set home_assistant.url "
                          "http://homeassistant.local:8123  and set the HA_TOKEN environment variable "
                          "(a long-lived token from your Home Assistant profile page).")
    return http_json(url + path, data, headers={"Authorization": f"Bearer {token}"}, timeout=12, method=method)


def ha_states(app: "App", fresh: bool = False) -> list[dict]:
    if fresh or time.time() - _HA_CACHE["t"] > 5:
        _HA_CACHE["states"] = ha_request(app, "GET", "/api/states") or []
        _HA_CACHE["t"] = time.time()
    return _HA_CACHE["states"]


def _norm(s: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9]+", (s or "").lower().replace("_", " ")) if t not in ("the", "my", "all", "in", "of")]


def ha_find(app: "App", query: str) -> list[dict]:
    states = ha_states(app)
    q = (query or "").strip().lower()
    if not q:
        return []
    exact = [s for s in states if s["entity_id"].lower() == q]
    if exact:
        return exact
    toks = _norm(q)
    want_domain = next((DOMAIN_WORDS[t] for t in toks if t in DOMAIN_WORDS), None)
    words = [t for t in toks if t not in DOMAIN_WORDS]
    pool = [s for s in states if not want_domain or s["entity_id"].split(".")[0] == want_domain]
    if not words:  # "all lights", "the fans"
        return pool if want_domain else []
    scored = []
    for s in pool:
        name_toks = set(_norm(s.get("attributes", {}).get("friendly_name", "")) + _norm(s["entity_id"].split(".", 1)[1]))
        hit = sum(1 for w in words if w in name_toks or any(n.startswith(w) for n in name_toks if len(w) >= 3))
        if hit:
            scored.append((hit / len(words), s))
    if not scored:
        return []
    best = max(sc for sc, _ in scored)
    return [s for sc, s in scored if sc == best and sc >= 0.5]


def _ha_name(s: dict) -> str:
    return s.get("attributes", {}).get("friendly_name") or s["entity_id"]


def _ha_fmt(s: dict) -> str:
    a = s.get("attributes", {})
    extra = []
    if a.get("brightness") is not None and s["state"] == "on":
        extra.append(f"{round(a['brightness'] / 2.55)}%")
    if a.get("current_temperature") is not None:
        extra.append(f"now {a['current_temperature']}°")
    if a.get("temperature") is not None and s["entity_id"].startswith("climate."):
        extra.append(f"target {a['temperature']}°")
    if a.get("unit_of_measurement"):
        return f"{_ha_name(s)}: {s['state']} {a['unit_of_measurement']}  ({s['entity_id']})"
    return f"{_ha_name(s)}: {s['state']}{' (' + ', '.join(extra) + ')' if extra else ''}  ({s['entity_id']})"
