"""Smart home tools (Home Assistant)."""

from __future__ import annotations

from ..home import _HA_CACHE, _ha_fmt, _ha_name, ha_find, ha_request, ha_states
from ..registry import S, tool


@tool("home_status", "Smart home: get the state of devices/sensors (lights, switches, thermostats, doors, "
      "temperature...). Leave query blank for a summary of everything.",
      {"query": S("Device, room or type, e.g. 'living room light', 'thermostat', 'all lights'")})
def t_home_status(ag, query: str = ""):
    if query.strip():
        found = ha_find(ag.app, query)
        return "\n".join(_ha_fmt(s) for s in found[:40]) or f"No device matches '{query}'."
    states = ha_states(ag.app, fresh=True)
    interesting = ("light", "switch", "fan", "climate", "lock", "cover", "media_player", "binary_sensor")
    rows = [s for s in states if s["entity_id"].split(".")[0] in interesting]
    on = [s for s in rows if s["state"] in ("on", "open", "unlocked", "playing", "heat", "cool")]
    out = [f"{len(rows)} devices, {len(on)} active:"] + [f"- {_ha_fmt(s)}" for s in on[:40]]
    temps = [s for s in states if s.get("attributes", {}).get("device_class") == "temperature"][:6]
    if temps:
        out += ["Temperatures:"] + [f"- {_ha_fmt(s)}" for s in temps]
    return "\n".join(out)


def _home_needs_approval(ag, args) -> bool:
    safe = set(ag.app.cfg.get("home_assistant.auto_approve_domains") or [])
    try:
        found = ha_find(ag.app, args.get("device", ""))
    except Exception:
        return True
    return not found or any(s["entity_id"].split(".")[0] not in safe for s in found)


@tool("home_control", "Smart home: control devices by name. Actions: turn_on, turn_off, toggle, open, close, "
      "lock, unlock, set (brightness/temperature). Works on groups like 'all lights' or 'bedroom'.",
      {"device": S("Device name, room or group, e.g. 'kitchen light', 'all lights', 'thermostat'"),
       "action": S("turn_on | turn_off | toggle | open | close | lock | unlock | set"),
       "brightness_pct": S("Light brightness 0-100 (optional)", "integer"),
       "temperature": S("Thermostat target temperature (optional)", "number")},
      ["device", "action"], risky=_home_needs_approval)
def t_home_control(ag, device: str, action: str, brightness_pct: int | None = None, temperature: float | None = None):
    found = ha_find(ag.app, device)
    if not found:
        names = ", ".join(sorted({_ha_name(s) for s in ha_states(ag.app)
                                  if s["entity_id"].split(".")[0] in ("light", "switch", "fan", "climate", "media_player")})[:30])
        return f"Error: no device matches '{device}'. Known devices include: {names}"
    action = (action or "").lower().replace(" ", "_")
    by_domain: dict[str, list[str]] = {}
    for s in found:
        by_domain.setdefault(s["entity_id"].split(".")[0], []).append(s["entity_id"])
    done = []
    for domain, ids in by_domain.items():
        data: dict = {"entity_id": ids}
        if domain == "climate" and (action == "set" or temperature is not None):
            service, data["temperature"] = "set_temperature", temperature
        elif domain == "light" and (action == "set" or brightness_pct is not None) and action != "turn_off":
            service, data["brightness_pct"] = "turn_on", max(0, min(100, int(brightness_pct or 100)))
        elif domain == "cover":
            service = {"open": "open_cover", "turn_on": "open_cover", "close": "close_cover",
                       "turn_off": "close_cover", "toggle": "toggle"}.get(action, action)
        elif domain == "lock":
            service = {"lock": "lock", "turn_on": "lock", "close": "lock", "unlock": "unlock",
                       "turn_off": "unlock", "open": "unlock"}.get(action, action)
        elif domain in ("scene", "script"):
            service = "turn_on"
        else:
            service = {"open": "turn_on", "close": "turn_off", "set": "turn_on"}.get(action, action)
        ha_request(ag.app, "POST", f"/api/services/{domain}/{service}", data)
        done.append(f"{domain}.{service} -> {', '.join(_ha_name(s) for s in found if s['entity_id'] in ids)}")
    _HA_CACHE["t"] = 0
    return "Done: " + "; ".join(done)
