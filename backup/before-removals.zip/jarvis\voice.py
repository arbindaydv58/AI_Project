"""Hands-free voice assistant for the terminal."""

from __future__ import annotations

import os
import queue
import re
import tempfile
import time
from typing import TYPE_CHECKING

from .agent import Agent, fmt_stats
from .cli import cli_approver, cli_events
from .common import bold, cyan, dim, magenta, red, yellow
from .errors import EngineError
from .speech import speak, transcribe_file, tts_command, wake_regex, whisper_available

if TYPE_CHECKING:
    from .app import App


def voice_loop(app: "App", wake: bool = False, preset: str | None = None, routing: str | None = None,
               model: str | None = None):
    """Hands-free terminal voice assistant: microphone -> Whisper -> agent -> speech."""
    problem = ""
    try:
        import numpy as np
        import sounddevice as sd
    except ImportError:
        np = sd = None
    except OSError as e:  # sounddevice installed but the PortAudio system library is missing
        np = sd = None
        problem = (f"\n  Audio library problem: {e}.\n  Linux: sudo apt install libportaudio2   "
                   "macOS: brew install portaudio")
    if np is None or not whisper_available():
        print(yellow("Terminal voice mode needs three optional packages:\n") +
              "    pip install faster-whisper sounddevice numpy" + problem + "\n" +
              dim("No install needed for voice in the web app: run `python main.py gui` and click the 🎙 Voice button."))
        return 1
    import wave
    rate, block = 16000, 480  # 30 ms frames
    rx = wake_regex(app.cfg.get("voice.wake_word", "jarvis"))
    word = app.cfg.get("voice.wake_word", "jarvis")
    agent = Agent(app, preset=preset, approver=cli_approver, on_event=cli_events, routing=routing, model=model)
    has_tts = tts_command() is not None

    def rms(x):
        return float(np.sqrt(np.mean(np.square(x)))) if len(x) else 0.0

    print(dim("Calibrating microphone - stay quiet for a second..."))
    noise = sd.rec(int(0.8 * rate), samplerate=rate, channels=1, dtype="float32")
    sd.wait()
    thr = max(0.012, rms(noise[:, 0]) * 3.0)

    def record(max_wait: float = 1e9) -> "np.ndarray | None":
        q: queue.Queue = queue.Queue()
        frames, pre, started, silent, t0 = [], [], False, 0, time.time()
        with sd.InputStream(samplerate=rate, channels=1, dtype="float32", blocksize=block,
                            callback=lambda d, *_: q.put(d[:, 0].copy())):
            while True:
                f = q.get()
                loud = rms(f) > thr
                if not started:
                    pre = (pre + [f])[-10:]  # 300 ms pre-roll
                    if loud:
                        started, frames = True, pre[:]
                    elif time.time() - t0 > max_wait:
                        return None
                    continue
                frames.append(f)
                silent = 0 if loud else silent + 1
                if silent > 30 or len(frames) > 30 * rate / block:  # 0.9 s silence or 30 s max
                    return np.concatenate(frames)

    def to_text(audio) -> str:
        fd, path = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        try:
            with wave.open(path, "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(rate)
                w.writeframes((np.clip(audio, -1, 1) * 32767).astype("<i2").tobytes())
            return transcribe_file(path, app.cfg)
        finally:
            os.unlink(path)

    def say(t: str):
        print(magenta("jarvis ›") + " " + t)
        if has_tts:
            speak(t)

    print(bold(cyan("\n  J A R V I S  voice mode")) + dim(f"  · {'say “' + word.title() + ', …”' if wake else 'just talk'}"
                                                         " · Ctrl+C to quit"))
    if not has_tts:
        print(yellow("  (No text-to-speech engine found - answers will be printed only. Linux: install espeak-ng)"))
    say(f"Online and listening{', ' + app.cfg.get('agent.user_name') if app.cfg.get('agent.user_name') else ''}.")
    while True:
        try:
            print(dim("  ● listening..."), end="\r", flush=True)
            audio = record()
            text = to_text(audio) if audio is not None else ""
            if not text:
                continue
            if wake:
                m = rx.match(text)
                if not m:
                    continue
                text = m.group(1).strip()
                if not text:
                    say("Yes?")
                    audio = record(max_wait=8)
                    text = to_text(audio) if audio is not None else ""
                    if not text:
                        continue
            print(" " * 20, end="\r")
            print(cyan("you ›") + " " + text)
            if re.fullmatch(r"\W*(stop|goodbye|good bye|exit|quit|shut ?down)\W*", text, re.I):
                say("Goodbye.")
                return 0
            out = agent.run(text)
            print(dim("  " + fmt_stats(agent.last_stats)))
            say(out)
        except KeyboardInterrupt:
            print("\nVoice mode stopped.")
            return 0
        except EngineError as e:
            print(red(f"  {e}"))
