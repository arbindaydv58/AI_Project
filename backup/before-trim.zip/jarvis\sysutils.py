"""Small OS helpers: system info, desktop notifications and battery level."""

from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
from pathlib import Path

from .common import IS_WIN


def _sysinfo() -> str:
    lines = [f"OS: {platform.system()} {platform.release()} ({platform.machine()})",
             f"Python: {platform.python_version()}", f"CPUs: {os.cpu_count()}"]
    if hasattr(os, "getloadavg"):
        try:
            lines.append("Load avg: " + ", ".join(f"{x:.2f}" for x in os.getloadavg()))
        except OSError:
            pass
    try:
        if Path("/proc/meminfo").exists():
            mi = dict(re.findall(r"(\w+):\s+(\d+)", Path("/proc/meminfo").read_text()))
            tot, av = int(mi["MemTotal"]) / 1048576, int(mi.get("MemAvailable", 0)) / 1048576
            lines.append(f"Memory: {av:.1f} GB free of {tot:.1f} GB")
        elif platform.system() == "Darwin":
            tot = int(subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True).stdout) / 2**30
            lines.append(f"Memory: {tot:.1f} GB total")
    except Exception:
        pass
    du = shutil.disk_usage(str(Path.home()))
    lines.append(f"Disk (home): {du.free / 2**30:.1f} GB free of {du.total / 2**30:.1f} GB")
    for bat in Path("/sys/class/power_supply").glob("BAT*") if Path("/sys/class/power_supply").exists() else []:
        try:
            lines.append(f"Battery: {(bat / 'capacity').read_text().strip()}% ({(bat / 'status').read_text().strip()})")
        except Exception:
            pass
    return "\n".join(lines)


def notify(title: str, msg: str):
    sysname = platform.system()
    try:
        if sysname == "Darwin":
            subprocess.run(["osascript", "-e", f"display notification {json.dumps(msg[:240], ensure_ascii=False)} "
                                               f"with title {json.dumps(title, ensure_ascii=False)}"], timeout=5)
        elif sysname == "Linux" and shutil.which("notify-send"):
            subprocess.run(["notify-send", title, msg[:400]], timeout=5)
        elif sysname == "Windows":
            ps = ("Add-Type -AssemblyName System.Windows.Forms; $n=New-Object System.Windows.Forms.NotifyIcon;"
                  "$n.Icon=[System.Drawing.SystemIcons]::Information;$n.Visible=$true;"
                  f"$n.ShowBalloonTip(8000,{json.dumps(title)},{json.dumps(msg[:240])},'Info');Start-Sleep 9;$n.Dispose()")
            subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps])
    except Exception:
        pass


def _battery() -> tuple[int, bool] | None:
    """(percent, charging) or None if unknown."""
    try:
        bats = list(Path("/sys/class/power_supply").glob("BAT*"))
        if bats:
            pct = int((bats[0] / "capacity").read_text().strip())
            st = (bats[0] / "status").read_text().strip().lower()
            return pct, st in ("charging", "full")
        if platform.system() == "Darwin":
            out = subprocess.run(["pmset", "-g", "batt"], capture_output=True, text=True, timeout=5).stdout
            m = re.search(r"(\d+)%;\s*(\w+)", out)
            if m:
                return int(m.group(1)), m.group(2).lower() in ("charging", "charged", "finishing")
        if IS_WIN:
            out = subprocess.run(["powershell", "-NoProfile", "-Command",
                                  "Get-CimInstance Win32_Battery | Select-Object -First 1 "
                                  "EstimatedChargeRemaining,BatteryStatus | ConvertTo-Json"],
                                 capture_output=True, text=True, timeout=10).stdout
            if out.strip():
                d = json.loads(out)
                return int(d.get("EstimatedChargeRemaining") or 0), int(d.get("BatteryStatus") or 1) == 2
    except Exception:
        pass
    return None
