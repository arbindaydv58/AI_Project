# Jarvis plan for this laptop

## Goal

A small local assistant that starts with one double-click, answers quickly on this laptop, and does a short list of useful things well. Everything is installed on D:.

The laptop is an Intel Core 7 150U with 16 GB of RAM, no GPU (Intel Graphics with 128 MB) and Windows 11. C: has about 41 GB free and D: about 225 GB. Ollama runs the model on the CPU only, so the size of the prompt sent to the model is what decides how fast Jarvis feels.

## What "simple" means here

- One way to start: double-click `start_jarvis.bat`, or run `python main.py`.
- No pip packages. Only the Python standard library and Ollama.
- A plain question is answered in under 5 seconds. A question that uses a tool is answered in under 30 seconds.
- Features that need hardware or accounts this laptop does not have are removed. Everything else stays.
- A short README and one small test file, so later changes do not break it.

## Baseline (measured on 2026-10-17, model qwen3:4b-instruct)

| Preset | Tools | Prompt size (estimated tokens) | Plain question | Question with a tool |
|---|---|---|---|---|
| chat | 0 | 50 | 3.9 s | not available |
| lite (default) | 8 | 930 | 3.4 s | 36.5 s |
| jarvis | 27 | 3,000 | not measured | 114 to 131 s |

The model writes 6 to 14 tokens per second. A question with a tool makes two model calls, and each call first reads the whole prompt.

## What stays and what goes

Removed, because they need something this laptop or its owner does not have:

- The Telegram bot. It needs a bot token and sends messages out of the machine.
- Home Assistant. It needs a Home Assistant server. This covers the smart home tools, the `home` command, the `ha_state` watcher and the home steps in protocols.
- Terminal voice mode (the `voice` command). It needs numpy, sounddevice and faster-whisper. Voice in the web app stays.

Changed:

- Energy numbers are no longer shown on this machine. They are 25 watts times the elapsed time, which is a guess. Real counters are still used on machines that have them.

Kept as is:

- Cloud engines and routing stay switched off because there is no API key.
- Document search, memory, the scheduler, the morning brief, the battery and disk watchers, and the `jarvis` preset with all 27 tools for the rare case where speed does not matter.

## Steps

Each step is done when its check passes. Boxes are ticked as the work is finished.

### 1. Safety copy

- [ ] Zip `main.py` and `jarvis/` into `backup\before-trim.zip`. Check: the zip exists and lists the files. The original single file is already in `backup\jarvis_single_file.py`.

### 2. Speed

- [ ] 2a. Move the clock out of the system prompt and into the message that is sent. The clock changes every minute and sits before the tool list, so Ollama probably cannot reuse its cached prompt for a follow-up question. Check: a follow-up asked more than a minute after the first is faster than before. If it is not, revert.
- [ ] 2b. Try 4, 6, 8 and 12 CPU threads on a fixed prompt. Add an `engine.num_thread` setting only if one value is at least 15% faster than the default.
- [ ] 2c. Point the two benchmark questions that use tools at the lite preset, run `python main.py bench`, and write accuracy and speed in the results table below.
- [ ] 2d. Only if a question with a tool still takes over 30 seconds: pull `qwen3:1.7b`, run the same benchmark and choose the model from the numbers.

### 3. Windows fixes

- [ ] Read battery with `GetSystemPowerStatus`, memory with `GlobalMemoryStatusEx` and CPU with `GetSystemTimes`, all through the built-in `ctypes`. Today the battery check starts a PowerShell process every time, and with the HUD on the web page that happens every 5 seconds. Memory and CPU readings are missing on Windows. Check: `system_info`, the RAM watcher and the HUD gauges show values.
- [ ] Make the reasoning filter handle a closing `</think>` that has no opening tag, so a thinking model cannot show its reasoning in replies. Check: a unit test with the exact text the model returned earlier.
- [ ] Stop showing energy numbers when the machine has no power counters. Check: the line under a reply no longer ends with a joule figure.

### 4. Remove what this laptop cannot use

- [ ] Telegram bot, then Home Assistant, then terminal voice mode, one at a time. Check after each: no leftover imports or undefined names, `python main.py doctor` runs cleanly, and the command list and help no longer mention it.

### 5. Laptop defaults and launcher

- [ ] Pull `nomic-embed-text` (about 270 MB) so memory and document search also match by meaning.
- [ ] Set `OLLAMA_KEEP_ALIVE` to 30m so the model stays in memory between questions, then restart Ollama.
- [ ] Add `start_jarvis.bat`. It starts Ollama if it is not running, then starts the web app and opens the browser. Check: double-clicking it gives a working chat page.

### 6. Tests and README

- [ ] `tests/test_basics.py`, using only `unittest`. It covers the calculator, the security rules, the tool list, the agent loop with a fake model, the reasoning filter and the web endpoints. Check: `python -m unittest discover tests` passes.
- [ ] `README.md`: how to start, where the files live, how to change the model and the preset, and how to undo a change.

### 7. Final check

- [ ] Run the static checks, the tests and `doctor`. Time a plain question and a question with a tool. Fill in the results table.

## Results

| Measure | Before | After |
|---|---|---|
| Plain question | 3.4 s | |
| Question with a tool | 36.5 s | |
| Lines of Python | 4,915 in one file; about 4,440 in 41 files after the split | |
| Pip packages needed | 0 | |

## Undo

The state before step 4 is in `backup\before-trim.zip`. The original single file is in `backup\jarvis_single_file.py`.
